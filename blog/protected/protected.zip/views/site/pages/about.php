<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Ayuda',
);
?>
<h1>Quienes Somos</h1>
<table border="0" align="justify" >
    <thead>
        <tr>
            <th align="justify"><div align="justify">PRIVISEGOM Cía. Ltda. es una empresa solida especializada en el desarrollo de la seguridad privada, constituida por profesionales capacitados
permanentemente a fin de cuidar su integridad y proteger su inversión, se complementa con la calidad de nuestros servicios puestos a su disposición.
Contamos con un equipo de elite comprometido y con vocación de servicio para salvaguardar lo que más le interesa, al utilizar técnicas de seguridad
innovadoras a través de asesores en áreas brindando tranquilidad a nuestros clientes.</div></th>
        </tr>
    </thead>
    </table>

<h1>Misión</h1>
<table border="0" align="justify" >
    <thead>
        <tr>
            <th align="justify"><div align="justify">PRIVISEGCOM CIA.LTDA brindar un servicio de seguridad de alta calidad  cumplimiento con los estándares de servicios , teniendo un equipo elite
comprometido y con vocación de servicio para salvaguardar lo que más le interesa, al utilizar técnicas de seguridad innovadoras a través de asesores en
áreas brindando tranquilidad a nuestros clientes..</div></th>
        </tr>
    </thead>
    </table>

<h1>Visión</h1>
<table border="0" align="justify" >
    <thead>
        <tr>
            <th align="justify"><div align="justify">Convertirnos en una empresa líder en la seguridad integral, con profesionales que brinde confianza y honestidad, de esta forma garantizar el servicio
                    a nuestros clientes y brindar  alternativas de soluciones integrales para el desarrollo de sus actividades diarias. .</div></th>
        </tr>
    </thead>
    </table>

<h1>Objetivos</h1>
<table border="0" align="justify" >
    <thead>
        <tr>
            <th align="justify"><div align="justify">PRIVISEGOM Cía. Ltda. es una empresa solida especializada en el desarrollo de la seguridad privada, constituida por profesionales capacitados
permanentemente a fin de cuidar su integridad y proteger su inversión, se complementa con la calidad de nuestros servicios puestos a su disposición.
Contamos con un equipo de elite comprometido y con vocación de servicio para salvaguardar lo que más le interesa, al utilizar técnicas de seguridad
innovadoras a través de asesores en áreas brindando tranquilidad a nuestros clientes.</div></th>
        </tr>
    </thead>
    </table>
