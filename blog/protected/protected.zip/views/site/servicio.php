<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Ayuda',
);
?>
<h1>Nuestros Servicios</h1>

                <h4><div WIDTH=90% align="justify">
SEGURIDAD FISICA<br><br>

	Vigilancia armada y uniformada.<br>
	Protección VIP (guardaespaldas)<br>
	Seguridad para oficinas y locales comerciales<br>
	Seguridad en eventos públicos y privados<br>
	Seguridad a entidades financieras<br>
	Seguridad en fábricas, industrias y empresas agrícolas<br>
	Seguridad a instituciones educativas<br>
	Seguridad residencial<br>
	Seguridad a bares, restaurantes y sitios de entretenimiento<br>
	Asesoría en seguridad<br>
	Investigación privada<br>
	Capacitación en seguridad integral<br>
	Seguridad vehicular<br><br><br>

SEGURIDAD  ELECTRONICA<br><br>


	Control de Acceso<br>
	Sistema de Alarmas<br>
	Sistema de Incendios<br>
	Cámara CCTV<br>
	Cercas Eléctricas<br>
	Instalación de circuitos cerrados de televisión CCTV
CUSTODIA<br>
	Custodia Interprovinciales<br>
.</div> 

</h4>