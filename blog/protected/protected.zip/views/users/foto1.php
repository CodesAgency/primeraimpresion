<?php
/* @var $this UsersController */

$this->breadcrumbs=array(
	'Users'=>array('/users'),
	'Foto',
);
?>
<h1><?php echo 'Foto'; ?></h1>

<iframe src="s/mostrar.php" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
