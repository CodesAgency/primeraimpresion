	<style>
        #footer{
            background-color: orange;
            height: auto;
            padding: 15px;
            position:fixed;
            left:0px;
            bottom:0px;
            width: 100%;
        }
    </style>
    
    <footer class="page-footer font-small blue" id="footer">

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2018 Copyright:
  Consola de Administración Primera Impresión.
</div>
<!-- Copyright -->

</footer>

